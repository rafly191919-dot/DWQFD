const APPS_SCRIPT_URL = ""; // Isi dengan URL Web App Google Apps Script bila ingin sinkron ke Google Sheets.
const STORAGE_KEYS = {
  transactions: "dt_transactions_v1",
  suppliers: "dt_suppliers_v1",
};

const DEFAULT_SUPPLIERS = [
  { id: crypto.randomUUID(), name: "CV Lembah Hijau Perkasa", wa: "", active: true },
  { id: crypto.randomUUID(), name: "Koperasi Karya Mandiri", wa: "", active: true },
  { id: crypto.randomUUID(), name: "Tani Rampah Jaya", wa: "", active: true },
  { id: crypto.randomUUID(), name: "PT Putra Utama Lestari", wa: "", active: true },
  { id: crypto.randomUUID(), name: "PT Manunggal Adi Jaya", wa: "", active: true },
];

const state = {
  transactions: [],
  suppliers: [],
  editingTransactionId: null,
  currentView: "dashboard",
};

const el = {};

document.addEventListener("DOMContentLoaded", async () => {
  captureElements();
  bindMenu();
  bindTransactionForm();
  bindSupplierForm();
  bindSpreadsheetFilter();
  bindSyncButton();

  seedSuppliers();
  loadLocalData();
  setTodayDefault();
  await syncFromRemoteIfConfigured();
  renderAll();
});

function captureElements() {
  [
    "tanggal", "supplier", "sopir", "plat", "tenera", "dura", "total-display", "percent-tenera", "percent-dura",
    "validation-indicator", "save-btn", "transaction-form", "transaction-table-wrap", "supplier-list",
    "dashboard-summary", "dashboard-supplier-table", "dashboard-driver-table",
    "sheet-search", "sheet-date-filter", "sheet-supplier-filter", "clear-sheet-filter", "spreadsheet-table-wrap",
    "supplier-form", "supplier-edit-id", "supplier-name", "supplier-wa", "supplier-status", "supplier-table-wrap",
    "supplier-reset", "sync-btn", "sync-status", "page-title", "page-subtitle",
    "rekap-harian-content", "rekap-mingguan-content", "rekap-bulanan-content"
  ].forEach(id => el[toCamel(id)] = document.getElementById(id));
}

function toCamel(id) {
  return id.replace(/-([a-z])/g, (_, s) => s.toUpperCase());
}

function bindMenu() {
  document.querySelectorAll(".menu-link").forEach(button => {
    button.addEventListener("click", () => switchView(button.dataset.view));
  });
}

function switchView(view) {
  state.currentView = view;
  document.querySelectorAll(".menu-link").forEach(btn => btn.classList.toggle("active", btn.dataset.view === view));
  document.querySelectorAll(".view").forEach(section => section.classList.toggle("active", section.id === `view-${view}`));

  const map = {
    dashboard: ["Dashboard", "Ringkasan transaksi Dura Tenera hari ini."],
    input: ["Input Transaksi", "Input data baru dan lihat tabel transaksi."],
    "rekap-harian": ["Rekap Harian", "Rekap otomatis untuk tanggal hari ini."],
    "rekap-mingguan": ["Rekap Mingguan", "Rekap otomatis untuk minggu berjalan."],
    "rekap-bulanan": ["Rekap Bulanan", "Rekap otomatis untuk bulan berjalan."],
    spreadsheet: ["Spreadsheet", "Tampilan tabel panjang dengan pencarian dan filter."],
    supplier: ["Supplier", "Kelola master supplier utama."],
  };

  el.pageTitle.textContent = map[view][0];
  el.pageSubtitle.textContent = map[view][1];
}

function bindTransactionForm() {
  [el.tenera, el.dura].forEach(input => input.addEventListener("input", updateValidation));
  [el.tanggal, el.supplier, el.sopir, el.plat].forEach(input => input.addEventListener("input", updateValidation));

  el.transactionForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!isTransactionValid()) return;

    const transaction = buildTransactionPayload();
    if (state.editingTransactionId) {
      const index = state.transactions.findIndex(item => item.id === state.editingTransactionId);
      if (index >= 0) {
        transaction.id = state.editingTransactionId;
        transaction.createdAt = state.transactions[index].createdAt;
        state.transactions[index] = transaction;
      }
      state.editingTransactionId = null;
    } else {
      state.transactions.unshift(transaction);
    }

    saveLocalData();
    await pushTransactionToRemote("upsert", transaction);
    renderAll();
    el.transactionForm.reset();
    setTodayDefault();
    updateValidation();
    switchView("input");
  });

  document.getElementById("reset-btn").addEventListener("click", () => {
    state.editingTransactionId = null;
    setTodayDefault();
    updateValidation();
  });
}

function buildTransactionPayload() {
  const tanggal = el.tanggal.value;
  const tenera = Number(el.tenera.value || 0);
  const dura = Number(el.dura.value || 0);
  const total = tenera + dura;
  const stamp = new Date();

  return {
    id: state.editingTransactionId || generateTransactionId(tanggal),
    date: tanggal,
    time: formatTime(stamp),
    supplier: normalizeText(el.supplier.value),
    driver: normalizeText(el.sopir.value),
    plate: normalizeText(el.plat.value).toUpperCase(),
    tenera,
    dura,
    total,
    percentTenera: tenera,
    percentDura: dura,
    createdAt: stamp.toISOString(),
  };
}

function updateValidation() {
  const tenera = Number(el.tenera.value || 0);
  const dura = Number(el.dura.value || 0);
  const total = tenera + dura;

  el.totalDisplay.value = total;
  el.percentTenera.value = `${tenera}%`;
  el.percentDura.value = `${dura}%`;

  const valid = isTransactionValid();
  el.validationIndicator.textContent = valid ? "Valid: total 100" : "Tidak valid: total harus 100";
  el.validationIndicator.className = `validation-box ${valid ? "valid" : "invalid"}`;
  el.saveBtn.disabled = !valid;
}

function isTransactionValid() {
  const requiredFilled = [el.tanggal.value, el.supplier.value, el.sopir.value, el.plat.value].every(Boolean);
  return requiredFilled && Number(el.tenera.value || 0) + Number(el.dura.value || 0) === 100;
}

function bindSupplierForm() {
  el.supplierForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const payload = {
      id: el.supplierEditId.value || crypto.randomUUID(),
      name: normalizeText(el.supplierName.value),
      wa: normalizeText(el.supplierWa.value),
      active: el.supplierStatus.value === "true",
    };

    if (!payload.name) return;

    const index = state.suppliers.findIndex(item => item.id === payload.id);
    if (index >= 0) {
      state.suppliers[index] = payload;
    } else {
      state.suppliers.unshift(payload);
    }

    saveLocalData();
    resetSupplierForm();
    renderAll();
  });

  el.supplierReset.addEventListener("click", resetSupplierForm);
}

function resetSupplierForm() {
  el.supplierForm.reset();
  el.supplierEditId.value = "";
  el.supplierStatus.value = "true";
}

function bindSpreadsheetFilter() {
  [el.sheetSearch, el.sheetDateFilter, el.sheetSupplierFilter].forEach(input => input.addEventListener("input", renderSpreadsheetView));
  el.clearSheetFilter.addEventListener("click", () => {
    el.sheetSearch.value = "";
    el.sheetDateFilter.value = "";
    el.sheetSupplierFilter.value = "";
    renderSpreadsheetView();
  });
}

function bindSyncButton() {
  el.syncBtn.addEventListener("click", async () => {
    await syncFromRemoteIfConfigured(true);
    renderAll();
  });
}

function seedSuppliers() {
  if (!localStorage.getItem(STORAGE_KEYS.suppliers)) {
    localStorage.setItem(STORAGE_KEYS.suppliers, JSON.stringify(DEFAULT_SUPPLIERS));
  }
}

function loadLocalData() {
  state.transactions = JSON.parse(localStorage.getItem(STORAGE_KEYS.transactions) || "[]");
  state.suppliers = JSON.parse(localStorage.getItem(STORAGE_KEYS.suppliers) || "[]");
}

function saveLocalData() {
  localStorage.setItem(STORAGE_KEYS.transactions, JSON.stringify(state.transactions));
  localStorage.setItem(STORAGE_KEYS.suppliers, JSON.stringify(state.suppliers));
}

function setTodayDefault() {
  el.tanggal.value = formatDateInput(new Date());
}

async function syncFromRemoteIfConfigured(showAlert = false) {
  if (!APPS_SCRIPT_URL) {
    setSyncStatus("Mode Local", "neutral");
    return;
  }

  try {
    setSyncStatus("Sync aktif", "success");
    const response = await fetch(`${APPS_SCRIPT_URL}?action=list`);
    const result = await response.json();

    if (Array.isArray(result.transactions)) {
      state.transactions = result.transactions;
      localStorage.setItem(STORAGE_KEYS.transactions, JSON.stringify(result.transactions));
    }
    if (Array.isArray(result.suppliers)) {
      state.suppliers = result.suppliers;
      localStorage.setItem(STORAGE_KEYS.suppliers, JSON.stringify(result.suppliers));
    }
    if (showAlert) alert("Data berhasil di-sync.");
  } catch (error) {
    console.error(error);
    setSyncStatus("Sync gagal", "neutral");
    if (showAlert) alert("Sync gagal. Tetap memakai data local.");
  }
}

async function pushTransactionToRemote(action, transaction) {
  if (!APPS_SCRIPT_URL) return;
  try {
    await fetch(APPS_SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ action, transaction, suppliers: state.suppliers }),
    });
  } catch (error) {
    console.error("Push remote gagal", error);
  }
}

function setSyncStatus(text, type) {
  el.syncStatus.textContent = text;
  el.syncStatus.className = `status-pill ${type}`;
}

function renderAll() {
  renderSupplierOptions();
  renderDashboard();
  renderTransactionsTable();
  renderRekaps();
  renderSpreadsheetFilters();
  renderSpreadsheetView();
  renderSupplierTable();
  updateValidation();
}

function renderSupplierOptions() {
  const activeSuppliers = state.suppliers.filter(item => item.active);
  el.supplierList.innerHTML = activeSuppliers.map(item => `<option value="${escapeHtml(item.name)}"></option>`).join("");
  el.sheetSupplierFilter.innerHTML = `<option value="">Semua Supplier</option>${activeSuppliers.map(item => `<option value="${escapeHtml(item.name)}">${escapeHtml(item.name)}</option>`).join("")}`;
}

function renderDashboard() {
  const today = formatDateInput(new Date());
  const todayTransactions = state.transactions.filter(item => item.date === today);
  const summary = computeSummary(todayTransactions);

  el.dashboardSummary.innerHTML = renderOrderedSummary(summary, "Hari Ini");
  el.dashboardSupplierTable.innerHTML = renderSimpleGroupTable(groupBy(todayTransactions, "supplier"), "Supplier");
  el.dashboardDriverTable.innerHTML = renderSimpleGroupTable(groupBy(todayTransactions, "driver"), "Sopir");
}

function renderTransactionsTable() {
  if (!state.transactions.length) {
    el.transactionTableWrap.innerHTML = `<div class="empty-state">Belum ada transaksi.</div>`;
    return;
  }

  const rows = state.transactions
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(item => `
      <tr>
        <td>${escapeHtml(item.id)}</td>
        <td>${formatDateDisplay(item.date)}</td>
        <td>${escapeHtml(item.time)}</td>
        <td>${escapeHtml(item.supplier)}</td>
        <td>${escapeHtml(item.driver)}</td>
        <td>${escapeHtml(item.plate)}</td>
        <td>${item.tenera}</td>
        <td>${item.dura}</td>
        <td>${item.total}</td>
        <td>${item.percentTenera}%</td>
        <td>${item.percentDura}%</td>
        <td>
          <div class="actions">
            <button class="btn btn-secondary small-btn" onclick="startEditTransaction('${item.id}')">Edit</button>
            <button class="btn btn-danger small-btn" onclick="deleteTransaction('${item.id}')">Hapus</button>
          </div>
        </td>
      </tr>
    `).join("");

  el.transactionTableWrap.innerHTML = renderTable([
    "ID Transaksi", "Tanggal", "Jam", "Supplier", "Sopir", "Plat", "Tenera", "Dura", "Total", "% Tenera", "% Dura", "Aksi"
  ], rows);
}

function renderRekaps() {
  const now = new Date();
  const today = formatDateInput(now);
  const currentWeek = state.transactions.filter(item => isDateInCurrentWeek(item.date, now));
  const currentMonth = state.transactions.filter(item => isDateInCurrentMonth(item.date, now));
  const currentDay = state.transactions.filter(item => item.date === today);

  el.rekapHarianContent.innerHTML = renderRekapBlock("Rekap Harian", currentDay);
  el.rekapMingguanContent.innerHTML = renderRekapBlock("Rekap Mingguan", currentWeek);
  el.rekapBulananContent.innerHTML = renderRekapBlock("Rekap Bulanan", currentMonth);
}

function renderRekapBlock(title, items) {
  const summary = computeSummary(items);
  return `
    <div class="panel">
      <div class="panel-header">
        <h3>${title}</h3>
        <p>Urutan: Total → Persentase → Kesimpulan → Detail tabel.</p>
      </div>
      ${renderOrderedSummary(summary, title)}
      <div class="grid-2">
        <div class="panel">
          <div class="panel-header"><h3>Detail per Supplier</h3></div>
          ${renderSimpleGroupTable(groupBy(items, "supplier"), "Supplier")}
        </div>
        <div class="panel">
          <div class="panel-header"><h3>Detail per Sopir</h3></div>
          ${renderSimpleGroupTable(groupBy(items, "driver"), "Sopir")}
        </div>
      </div>
      <div class="panel">
        <div class="panel-header"><h3>Detail Tabel</h3></div>
        ${renderTransactionDetailTable(items)}
      </div>
    </div>
  `;
}

function renderOrderedSummary(summary, label) {
  return `
    <div class="section-block">
      <h4 class="section-title">1. Total</h4>
      <div class="summary-top">
        <div class="card"><h4>Total Transaksi</h4><div class="metric">${summary.totalTransactions}</div><div class="muted">Jumlah transaksi ${label.toLowerCase()}</div></div>
        <div class="card"><h4>Total Tenera</h4><div class="metric">${summary.totalTenera}</div><div class="muted">Akumulasi nilai tenera</div></div>
        <div class="card"><h4>Total Dura</h4><div class="metric">${summary.totalDura}</div><div class="muted">Akumulasi nilai dura</div></div>
      </div>
    </div>

    <div class="section-block">
      <h4 class="section-title">2. Persentase</h4>
      <div class="summary-top">
        <div class="card"><h4>% Tenera</h4><div class="metric">${summary.percentTenera}%</div><div class="muted">Persentase akumulasi tenera</div></div>
        <div class="card"><h4>% Dura</h4><div class="metric">${summary.percentDura}%</div><div class="muted">Persentase akumulasi dura</div></div>
        <div class="card"><h4>Rasio</h4><div class="metric">${summary.totalTenera}:${summary.totalDura}</div><div class="muted">Perbandingan total</div></div>
      </div>
    </div>

    <div class="section-block">
      <h4 class="section-title">3. Kesimpulan</h4>
      <div class="card">
        <ul class="kesimpulan-list">
          <li>Dominan: <strong>${summary.dominant}</strong></li>
          <li>Supplier tertinggi: <strong>${summary.topSupplier.name}</strong> (${summary.topSupplier.total})</li>
          <li>Sopir tertinggi: <strong>${summary.topDriver.name}</strong> (${summary.topDriver.total})</li>
        </ul>
      </div>
    </div>
  `;
}

function renderTransactionDetailTable(items) {
  if (!items.length) return `<div class="empty-state">Belum ada data pada periode ini.</div>`;
  const rows = [...items].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(item => `
    <tr>
      <td>${escapeHtml(item.id)}</td>
      <td>${formatDateDisplay(item.date)}</td>
      <td>${escapeHtml(item.time)}</td>
      <td>${escapeHtml(item.supplier)}</td>
      <td>${escapeHtml(item.driver)}</td>
      <td>${escapeHtml(item.plate)}</td>
      <td>${item.tenera}</td>
      <td>${item.dura}</td>
      <td>${item.total}</td>
      <td>${item.percentTenera}%</td>
      <td>${item.percentDura}%</td>
    </tr>
  `).join("");
  return renderTable(["ID", "Tanggal", "Jam", "Supplier", "Sopir", "Plat", "Tenera", "Dura", "Total", "% Tenera", "% Dura"], rows);
}

function renderSpreadsheetFilters() {
  // isi dropdown sudah dirender di renderSupplierOptions
}

function renderSpreadsheetView() {
  const search = (el.sheetSearch.value || "").toLowerCase();
  const dateFilter = el.sheetDateFilter.value;
  const supplierFilter = el.sheetSupplierFilter.value;

  const items = state.transactions.filter(item => {
    const searchMatch = !search || [item.id, item.supplier, item.driver, item.plate].join(" ").toLowerCase().includes(search);
    const dateMatch = !dateFilter || item.date === dateFilter;
    const supplierMatch = !supplierFilter || item.supplier === supplierFilter;
    return searchMatch && dateMatch && supplierMatch;
  });

  el.spreadsheetTableWrap.innerHTML = renderTransactionDetailTable(items);
}

function renderSupplierTable() {
  if (!state.suppliers.length) {
    el.supplierTableWrap.innerHTML = `<div class="empty-state">Belum ada supplier.</div>`;
    return;
  }

  const rows = state.suppliers.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${escapeHtml(item.wa || "-")}</td>
      <td><span class="tag">${item.active ? "Aktif" : "Nonaktif"}</span></td>
      <td>
        <div class="actions">
          <button class="btn btn-secondary" onclick="editSupplier('${item.id}')">Edit</button>
          <button class="btn btn-danger" onclick="deleteSupplier('${item.id}')">Hapus</button>
        </div>
      </td>
    </tr>
  `).join("");

  el.supplierTableWrap.innerHTML = renderTable(["Nama Supplier", "Nomor WA", "Status", "Aksi"], rows);
}

function renderSimpleGroupTable(groups, labelName) {
  if (!groups.length) return `<div class="empty-state">Belum ada data.</div>`;
  const rows = groups.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>${item.transactions}</td>
      <td>${item.tenera}</td>
      <td>${item.dura}</td>
      <td>${item.total}</td>
    </tr>
  `).join("");
  return renderTable([labelName, "Total Transaksi", "Total Tenera", "Total Dura", "Total"], rows);
}

function renderTable(headers, rows) {
  return `
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>${headers.map(head => `<th>${head}</th>`).join("")}</tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;
}

function computeSummary(items) {
  const totalTransactions = items.length;
  const totalTenera = items.reduce((sum, item) => sum + Number(item.tenera || 0), 0);
  const totalDura = items.reduce((sum, item) => sum + Number(item.dura || 0), 0);
  const grandTotal = totalTenera + totalDura;
  const percentTenera = grandTotal ? ((totalTenera / grandTotal) * 100).toFixed(2) : "0.00";
  const percentDura = grandTotal ? ((totalDura / grandTotal) * 100).toFixed(2) : "0.00";
  const dominant = totalTenera === totalDura ? "Seimbang" : totalTenera > totalDura ? "Tenera" : "Dura";
  const supplierGroups = groupBy(items, "supplier");
  const driverGroups = groupBy(items, "driver");

  return {
    totalTransactions,
    totalTenera,
    totalDura,
    percentTenera,
    percentDura,
    dominant,
    topSupplier: supplierGroups[0] || { name: "-", total: 0 },
    topDriver: driverGroups[0] || { name: "-", total: 0 },
  };
}

function groupBy(items, key) {
  const map = new Map();
  items.forEach(item => {
    const name = item[key] || "-";
    if (!map.has(name)) map.set(name, { name, transactions: 0, tenera: 0, dura: 0, total: 0 });
    const row = map.get(name);
    row.transactions += 1;
    row.tenera += Number(item.tenera || 0);
    row.dura += Number(item.dura || 0);
    row.total += Number(item.total || 0);
  });
  return [...map.values()].sort((a, b) => b.total - a.total || b.transactions - a.transactions || a.name.localeCompare(b.name));
}

function generateTransactionId(date) {
  const ymd = date.replaceAll("-", "");
  const sameDateCount = state.transactions.filter(item => item.date === date).length + 1;
  return `TRX-${ymd}-${String(sameDateCount).padStart(3, "0")}`;
}

function formatDateInput(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDateDisplay(dateString) {
  const date = new Date(`${dateString}T00:00:00`);
  return date.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}

function formatTime(date) {
  return date.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function isDateInCurrentWeek(dateString, baseDate = new Date()) {
  const date = new Date(`${dateString}T00:00:00`);
  const day = (baseDate.getDay() + 6) % 7;
  const monday = new Date(baseDate);
  monday.setDate(baseDate.getDate() - day);
  monday.setHours(0, 0, 0, 0);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);
  return date >= monday && date <= sunday;
}

function isDateInCurrentMonth(dateString, baseDate = new Date()) {
  const date = new Date(`${dateString}T00:00:00`);
  return date.getMonth() === baseDate.getMonth() && date.getFullYear() === baseDate.getFullYear();
}

function normalizeText(value) {
  return String(value || "").trim();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

window.deleteTransaction = async function(id) {
  if (!confirm("Hapus transaksi ini?")) return;
  state.transactions = state.transactions.filter(item => item.id !== id);
  saveLocalData();
  await pushTransactionToRemote("delete", { id });
  renderAll();
};

window.startEditTransaction = function(id) {
  const item = state.transactions.find(row => row.id === id);
  if (!item) return;
  state.editingTransactionId = id;
  el.tanggal.value = item.date;
  el.supplier.value = item.supplier;
  el.sopir.value = item.driver;
  el.plat.value = item.plate;
  el.tenera.value = item.tenera;
  el.dura.value = item.dura;
  updateValidation();
  switchView("input");
};

window.editSupplier = function(id) {
  const item = state.suppliers.find(row => row.id === id);
  if (!item) return;
  el.supplierEditId.value = item.id;
  el.supplierName.value = item.name;
  el.supplierWa.value = item.wa;
  el.supplierStatus.value = String(item.active);
  switchView("supplier");
};

window.deleteSupplier = function(id) {
  if (!confirm("Hapus supplier ini?")) return;
  state.suppliers = state.suppliers.filter(item => item.id !== id);
  saveLocalData();
  renderAll();
};
